# Color Picker
 A page which lets you pick gardient color code. 
