# Calculator
 A Calculator project that lets you perform basic mathematical operations with light & dark mode feature
